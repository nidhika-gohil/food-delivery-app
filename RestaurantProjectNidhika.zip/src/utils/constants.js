export const LOGO_URL =
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdtAc8_DYEXqXjxuCBK7AIEO4K9OmO3pDKcesV7JiHRl1WjlQQBZ_Sga5IwkTnCyQLPco&usqp=CAU";

export const CDN_URL =
  "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_508,h_320,c_fill/";

export const MENU_LIST =
  "https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=18.5070213&lng=73.80579139999999&catalog_qa=undefined&submitAction=ENTER&restaurantId="; // add restaurant id
