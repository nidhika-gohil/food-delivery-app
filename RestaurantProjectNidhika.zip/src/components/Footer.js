const Footer = () => {
  return <div className="footer-container"></div>;
};

export default Footer;
