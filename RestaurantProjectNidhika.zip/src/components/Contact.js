const Contact = () => {
  return (
    <div>
      <h1>For more details please contact us</h1>
      <p><b>Email:</b> gohilnidhika79@gmail.com</p>
      <p><b>Phone:</b> +919767062053</p>
    </div>
  );
};

export default Contact;
