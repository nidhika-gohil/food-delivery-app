const Grocery = () => {
  return <h1>Loaded Grocery Component</h1>;
};

export default Grocery;
